import json
import os
from telegram import Update
from telegram.ext import ContextTypes

DATA_FILE = "data.json"

# Функции для работы с файлами
def load_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w") as f:
            json.dump({}, f)
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

# Команда /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Welcome to the Financial Planner Bot! Use /help to see available commands.")

# Команда /help
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📋 Commands:\n"
        "/config [category] [amount] - Set budget\n"
        "/log [category] [amount] - Log expense/income\n"
        "/summary - Show budget summary\n"
        "/notifyon - Enable notifications\n"
        "/notifyoff - Disable notifications"
    )

# Команда /config
async def config(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = str(update.effective_user.id)
        category = context.args[0]
        amount = float(context.args[1])

        data = load_data()
        if user_id not in data:
            data[user_id] = {"config": {}, "logs": []}

        data[user_id]["config"][category] = amount
        save_data(data)

        await update.message.reply_text(f"✅ Set budget for '{category}' = {amount}")
    except Exception as e:
        print("Error in /config:", e)
        await update.message.reply_text("⚠️ Usage: /config [category] [amount]")

# Команда /log
async def log_entry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        user_id = str(update.effective_user.id)
        category = context.args[0]
        amount = float(context.args[1])

        data = load_data()
        if user_id not in data:
            data[user_id] = {"config": {}, "logs": []}

        data[user_id]["logs"].append({"category": category, "amount": amount})
        save_data(data)

        await update.message.reply_text(f"📝 Logged {amount} in '{category}'")
    except Exception as e:
        print("Error in /log:", e)
        await update.message.reply_text("⚠️ Usage: /log [category] [amount]")

# Команда /summary
async def summary(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = str(update.effective_user.id)
    data = load_data()

    if user_id not in data or not data[user_id]["config"]:
        await update.message.reply_text("❌ No budget data found. Use /config first.")
        return

    total_spent = {}
    for entry in data[user_id]["logs"]:
        cat = entry["category"]
        total_spent[cat] = total_spent.get(cat, 0) + entry["amount"]

    message = "📊 Budget Summary:\n"
    for cat, budget in data[user_id]["config"].items():
        spent = total_spent.get(cat, 0)
        message += f"• {cat}: Spent {spent} / Budget {budget}\n"

    await update.message.reply_text(message)

# Команды /notifyon и /notifyoff
async def notify_on(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔔 Notifications are now ON. (Not implemented yet)")

async def notify_off(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔕 Notifications are now OFF. (Not implemented yet)")
