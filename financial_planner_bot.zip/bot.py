import logging
import os
from dotenv import load_dotenv
from telegram.ext import ApplicationBuilder, CommandHandler

from handlers import (
    start,
    help_command,
    config,
    log_entry,
    summary,
    notify_on,
    notify_off,
)

# Загружаем токен
load_dotenv("keys.env")
TOKEN = os.getenv("BOT_TOKEN")

# Настройка логов
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

# Инициализация приложения
app = ApplicationBuilder().token(TOKEN).build()

# Регистрируем обработчики команд
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("help", help_command))
app.add_handler(CommandHandler("config", config))
app.add_handler(CommandHandler("log", log_entry))
app.add_handler(CommandHandler("summary", summary))
app.add_handler(CommandHandler("notifyon", notify_on))
app.add_handler(CommandHandler("notifyoff", notify_off))

# Запускаем бота
if __name__ == "__main__":
    print("🤖 Bot is running...")
    app.run_polling()


